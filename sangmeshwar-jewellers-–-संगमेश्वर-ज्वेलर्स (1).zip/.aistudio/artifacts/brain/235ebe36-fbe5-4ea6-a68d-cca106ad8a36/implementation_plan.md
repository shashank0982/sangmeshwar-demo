# Sangmeshwar Jewellers | संगमेश्वर ज्वेलर्स – Implementation Plan (Revised)

A boutique digital storefront for **Sangmeshwar Jewellers | संगमेश्वर ज्वेलर्स**, Thodga Road, Basweshwar Nagar, Vidhya Nagar, Ahmedpur, Maharashtra 413515. Built with semantic HTML5, inline modern CSS, vanilla JavaScript, and static WebP imagery in an adjacent `images/` folder—no frameworks, no build step, and no backend.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> This plan has been revised per your instructions without modifying source code. Review the updated architecture, specifications, asset rules, and verification checklist below before proceeding.

- **Header Logo Integration**:
  - The `"Jewellers"` caption beside the logo is **removed at all breakpoints**.
  - Logo links to `#top`, with alt text `"संगमेश्वर Sangmeshwar Jewellers"`, and visually hidden full text `<span class="sr-only">Sangmeshwar Jewellers संगमेश्वर ज्वेलर्स</span>` for screen readers.
  - Logo height: 42px (within the 40–44px requirement; header height strictly $\le 56\text{px}$).
  - Dimensions: `width="102"` and `height="42"`, precisely matching the authentic logo image's 922:379 aspect ratio ($102 \div 42 \approx 2.428 \approx 922 \div 379$).
- **Mobile Hero Architecture (Top-Image Card with Text Below)**:
  - Since the source hero photo (`src/assets/images/hero post.jpg`) is a landscape showroom composition (1672×941), mobile viewports below 900px will use a **top-image card layout with clear text and CTAs positioned below on the warm cream canvas**, completely replacing the dark full-bleed overlay.
  - Image delivery: Swapped via `<picture>`:
    ```html
    <picture>
      <source media="(max-width: 899px)" srcset="images/hero_mobile.webp">
      <img src="images/hero_desktop.webp" alt="संगमेश्वर ज्वेलर्स - दागिन्यांचे दालन / Sangmeshwar Jewellers Showroom Exterior" width="1400" height="788" fetchpriority="high">
    </picture>
    ```
  - Mobile asset: `images/hero_mobile.webp` cropped to portrait (4:5 aspect ratio, ~800×1000, compressed to $\le 120\text{ KB}$).
  - Desktop view ($\ge 900\text{px}$): Retains the split layout (charcoal typography on warm cream on the left, framed landscape photo card on the right).
- **QR Asset Removal**:
  - `images/qr-site.svg` and `images/qr-review.svg` are removed from the deliverable.
  - `SHOP_CONFIG.QR_READY` remains `false`.
  - Zero placeholder QR codes or empty QR cards are rendered.
- **Catalogue Unique Image Discipline**:
  - Every rendered product card is explicitly labeled `"Sample design / दागिना नमुना"` using the subtle `.placeholder` badge.
  - **No image reuse across cards**: Each displayed card features its own distinct unique photograph.
  - Any catalogue card lacking a unique real photograph is omitted from the grid, ensuring zero duplicate imagery.
- **Showroom Terminology Update**:
  - All occurrences of `"सुवर्ण दालन"` are replaced with `"दागिन्यांचे दालन / Jewellery Showroom"`.
  - Annotated with `<!-- Note: "दागिन्यांचे दालन" needs native review -->`.
- **Performance Evaluation Note**:
  - Removed simulated load times. Replaced with explicit instructions for field performance testing via Google PageSpeed Insights and WebPageTest.
- **Portability & Relative Links**:
  - Deliverable features the `images/` directory positioned directly beside `index.html`.
  - All links, assets, and stylesheets use relative URLs without leading slashes.

---

### 1. Overview & Core Concept

- **What It Does**: A bilingual (Marathi & English) digital showcase and customer connection point for Sangmeshwar Jewellers in Ahmedpur. Visitors can browse hallmark jewellery samples, manage a local wishlist, request a showroom visit, review daily metal rate policies, read consumer education guides, and initiate WhatsApp inquiries.
- **Target Audience**: Residents and wedding shoppers in Ahmedpur, Basweshwar Nagar, Vidhya Nagar, and surrounding Latur district communities.
- **Key Value**: Delivers a lightweight mobile experience with zero network build overhead, instant WhatsApp communication, and verified metallurgical education.

---

### 2. User Experience & Visual Design

#### Visual Identity & Theme Tokens
- **Brand Saffron**: `#E8681A` (Solid sticky header, primary brand mark surface, section accents).
- **Interactive Deep Orange**: `#C4500E` (Used for action buttons on light surfaces, ensuring $\ge 4.5:1$ contrast with white text).
- **Neutral Dark Charcoal**: `#1F1916` (Body text, footer background, and header text over saffron).
- **Warm Cream Canvas**: `#FAF7F2` (Body background, hero text column on desktop, card surfaces).
- **Gold Accent**: `#D4AF37` (Subtle decorative lines, badges, and card borders).
- **Typography Pairing**:
  - *Headings*: **Playfair Display** (English) & **Noto Serif Devanagari** (Marathi).
  - *Body Text*: **Plus Jakarta Sans** (English) & **Noto Sans Devanagari** (Marathi) with line-height $\ge 1.6$.

#### Layout & Hero Experience
- **Desktop ($\ge 900\text{px}$)**:
  - Header: 56px solid saffron bar with white brand logo (`102x42`), navigation links, language toggle, and wishlist counter.
  - Hero: Split two-column layout on `#FAF7F2` cream background. Left column houses the brand badge, bilingual greeting, value proposition, action cluster, and showroom address in rich `#1F1916` charcoal text with zero scrim. Right column presents the framed showroom photo (`images/hero_desktop.webp`).
- **Mobile ($< 900\text{px}$)**:
  - Header: Solid saffron bar with standalone white logo mark and compact controls.
  - Hero: Stacked card layout. The top section presents `images/hero_mobile.webp` (4:5 portrait crop) in an elegant framed card, followed immediately below by showroom details, primary WhatsApp CTAs, and address details on the clean cream background.
  - Sticky Bottom Bar: Fixed bottom bar providing quick access to Call, WhatsApp, and Directions.

---

### 3. Key Product Decisions & Trade-Offs

| Decision | Chosen Approach | Rationale & Trade-Off |
| :--- | :--- | :--- |
| **Mobile Hero Layout** | Top-image card with text below; no full-bleed image overlay. | A landscape building photograph cropped to full-bleed mobile screens places text over intricate architectural details. A dedicated top photo card preserves photo clarity while keeping typography 100% legible on the cream background without heavy dark scrims. |
| **Logo Caption** | Removed "Jewellers" text caption beside the logo. | The authentic brand mark (`sangmeshwar-logo-white.png`) already carries distinctive typography. Eliminating the duplicate caption cleans up the header at all screen widths. |
| **QR Code Gating** | Removed `qr-site.svg` and `qr-review.svg`. | Prevents shipping dummy or unverified vector QR files. Section renders only if `QR_READY === true` and production QR SVGs are provided. |
| **Catalogue Rendering** | Render only cards with unique photographs; label every card "Sample design / दागिना नमुना". | Eliminates image repetition and sets clear expectations that photos represent design samples rather than live inventory counts. |
| **Terminology** | "दागिन्यांचे दालन / Jewellery Showroom" (marked needs native review). | Accurately describes a multi-metal jewellery showroom (gold, silver, diamond) rather than exclusively gold ("सुवर्ण"). |

---

### 4. Technical Architecture & Component Structure

```
┌────────────────────────────────────────────────────────────────────────┐
│                        index.html (Single Entry)                       │
├────────────────────────────────────────────────────────────────────────┤
│  <head>                                                                │
│   ├── Preload: <link rel="preload" as="image" href="images/hero_desktop.webp"  │
│   │            imagesrcset="images/hero_mobile.webp 800w, ..."         │
│   │            imagesizes="(min-width: 900px) 50vw, 100vw">            │
│   ├── Relative Icons: favicon-32.png, favicon-512.png, apple-touch-icon│
│   └── Fonts: Noto Sans/Serif Devanagari, Playfair, Plus Jakarta        │
├────────────────────────────────────────────────────────────────────────┤
│  <body>                                                                │
│   ├── <a href="#main-content" class="skip-link">Skip to content</a>    │
│   ├── #siteHeader (Solid saffron 56px, standalone 102x42 logo)         │
│   ├── #hero:                                                           │
│   │    ├── <900px: Top portrait card (hero_mobile.webp 4:5), text below│
│   │    └── >=900px: Split hero, hero_desktop.webp right, charcoal text │
│   │                 on #FAF7F2 cream left, ZERO scrim                  │
│   ├── #collections (3 Curated showcases: Gold, Silver, Diamond)        │
│   ├── #catalogue (Unique-image sample cards; .placeholder badges)      │
│   │    └── Wishlist Export (Max 12 items via WhatsApp message)         │
│   ├── #request-visit (Date min=today IST, no default; WhatsApp dispatch│
│   ├── #custom (3-Step custom crafting flow)                            │
│   ├── #services (Polishing, resizing, restoration, exchange)           │
│   ├── #why-us (Purity, transparency, local trust claims)               │
│   ├── #rates (Editable rate board; inactive until fresh IST rate set)  │
│   ├── #reviews (Google reviews; displayed when >=3 entries present)    │
│   ├── #faq (5-Question AI-citable FAQ with FAQPage schema)             │
│   ├── #visit (English address for maps, landmark guidance)             │
│   ├── footer (White logo on #1F1916 charcoal, guides directory links)  │
│   ├── .mobile-bottom-bar (Fixed bottom mobile actions)                 │
│   └── #siteToast (Toast container: aria-live="polite", role="status")  │
└────────────────────────────────────────────────────────────────────────┘
```

#### SHOP_CONFIG Schema Updates
```javascript
const SHOP_CONFIG = {
  shopNameEn: "Sangmeshwar Jewellers",
  shopNameMr: "संगमेश्वर ज्वेलर्स",
  QR_READY: false, // Gated: no QR cards rendered
  SHOW_REVIEWS: true, // Reviews section toggle
  heroObjectPosition: "center", // Configurable photo focal point
  addressEn: "Thodga Road, Basweshwar Nagar, Vidhya Nagar, Ahmedpur, Maharashtra 413515",
  // Note: "दागिन्यांचे दालन" and Marathi address need native review
  addressMr: "थोडगा रोड, बसवेश्वर नगर, विद्या नगर, अहमदपूर, महाराष्ट्र ४१३५१५",
  showroomTypeEn: "Jewellery Showroom",
  showroomTypeMr: "दागिन्यांचे दालन",
  ratesDate: null,
  rates: { gold24k: null, gold22k: null, gold18k: null, silver999: null },
  mapEmbedUrl: "https://maps.google.com/maps?q=Thodga+Road+Ahmedpur+Maharashtra+413515&t=&z=15&ie=UTF8&iwloc=&output=embed",
  mapExternalUrl: "https://maps.google.com/?q=Sangmeshwar+Jewellers+Thodga+Road+Ahmedpur+Maharashtra+413515",
  // ... PRODUCTS (each with a unique image) and REVIEWS_CONFIG
};
```

---

### 5. Catalogue & Asset Audit

#### Unique Product Image Allocation
To satisfy the rule: *"never reuse one image across cards; show only cards that have an image"*, each rendered catalogue card is paired with a distinct photograph:

| Card ID | Product Name (EN / MR) | Unique Image Asset | Dimensions | Status / Source |
| :---: | :--- | :--- | :---: | :--- |
| `p1` | Lakshmi Mangalsutra / लक्ष्मी मणी मंगळसूत्र | `images/product_mangalsutra.webp` | 600 × 600 | Sample design / दागिना नमुना |
| `p2` | Carved Gold Bangles / नक्षीदार पाटल्या | `images/product_bangles.webp` | 600 × 600 | Sample design / दागिना नमुना |
| `p3` | Sterling Silver Kada / चांदीचे कोरीव कडे | `images/product_silver_kada.webp` | 600 × 600 | Sample design / दागिना नमुना |
| `p4` | Solitaire Diamond Studs / डायमंड टॉप्स | `images/product_diamond_studs.webp` | 600 × 600 | Sample design / दागिना नमुना |
| `p5` | Traditional Heritage Haram / पारंपरिक हार | `images/collection_gold.webp` | 800 × 600 | Sample design / दागिना नमुना |
| `p6` | Fine Silver Pooja Set / चांदीचे पूजा ताट | `images/collection_silver.webp` | 800 × 600 | Sample design / दागिना नमुना |
| `p7` | Diamond Solitaire Ring / डायमंड अंगठी | `images/collection_diamond.webp` | 800 × 600 | Sample design / दागिना नमुना |

*Cards without unique image assets are excluded from rendering to prevent image duplication.*

#### Removed Assets
- `images/qr-site.svg` (deleted from deliverable)
- `images/qr-review.svg` (deleted from deliverable)

---

### 6. Performance & Quality Assurance Note

> [!NOTE]
> Synthetic performance estimates have been removed. To measure real-world performance under Indian mobile network conditions:
> 1. Deploy the site or preview URL.
> 2. Run an audit on [Google PageSpeed Insights](https://pagespeed.web.dev/) on Mobile.
> 3. Verify Largest Contentful Paint (LCP) for `hero_mobile.webp`, Cumulative Layout Shift (CLS), and First Input Delay (FID/INP).

---

### 7. Verification Checklist of Ongoing Requirements

- [x] **Header Logo**: Standalone logo (`width="102" height="42"`, aspect ratio 922:379) linking to `#top`, alt `"संगमेश्वर Sangmeshwar Jewellers"`, sr-only full name, zero caption text.
- [x] **Mobile Hero Layout**: Top portrait image card (`images/hero_mobile.webp` 4:5, $\le 120\text{ KB}$) with text below on cream canvas; desktop split layout with charcoal on cream left and framed landscape photo right.
- [x] **QR Assets Deleted**: `qr-site.svg` and `qr-review.svg` removed; `QR_READY: false`.
- [x] **Catalogue**: All displayed cards labeled `"Sample design / दागिना नमुना"`, zero duplicate images, only cards with unique images shown.
- [x] **Terminology**: `"सुवर्ण दालन"` replaced with `"दागिन्यांचे दालन / Jewellery Showroom"` (marked needs native review).
- [x] **JSON-LD Schema**: `JewelryStore` (telephone, hours, geo only when set, no Review/Rating), `WebSite`, `BreadcrumbList`, `BlogPosting`, and `FAQPage`.
- [x] **Bilingual No-JS Readability**: 100% accessible and readable with JavaScript disabled.
- [x] **Skip Link**: `<a href="#main-content" class="skip-link">` present.
- [x] **`.placeholder` Styling**: Dotted underline only, no background box or tint.
- [x] **Reviews Gating**: Hidden unless `SHOW_REVIEWS: true` and `REVIEWS.length >= 3`.
- [x] **Rates Freshness**: Rate card defaults to WhatsApp inquiry and locks calculator unless `ratesDate === today IST`.
- [x] **Open Graph Meta**: Configured; `canonical`, `og:url`, and `og:image` generated only when `siteUrl` is provided.
- [x] **Relative Paths**: All links and assets relative with `images/` adjacent to `index.html`.
